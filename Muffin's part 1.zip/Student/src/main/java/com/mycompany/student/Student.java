/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.student;

/**
 *
 * @author Boikanyo
 */

public class Student {

    private String studentName;
    private String studentNumber;
    private double testMark;
    private double examMark;

    // Constructor
    public Student(String name, String number, double test, double exam) {
        studentName = name;
        studentNumber = number;
        testMark = test;
        examMark = exam;
    }

    // Display student details
    public void displayStudentDetails() {
        System.out.println("STUDENT DETAILS");
        System.out.println("-------------------------");
        System.out.println("Name: " + studentName);
        System.out.println("Student Number: " + studentNumber);
        System.out.println("Test Mark: " + testMark);
        System.out.println("Exam Mark: " + examMark);
    }

    public double calculateFinalMark() {
        return (testMark * 0.40) + (examMark * 0.60);
    }

    public void updateTestMark(double newMark) {
        testMark = newMark;
    }

    // Main method
    public static void main(String[] args) {

        // Create Student object
        Student student1 = new Student(
                "Boikanyo Fari",
                "ST10456789",
                100,
                100
        );

        // Display student details
        student1.displayStudentDetails();

        // Calculate final mark
        double finalMark = student1.calculateFinalMark();

        // Display final mark
        System.out.println("Final Mark: " + finalMark);

        // Update test mark from 70 to 85
        student1.updateTestMark(85);

        // Calculate new final mark
        double newFinalMark = student1.calculateFinalMark();

        // Display new final mark
        System.out.println("New Final Mark: " + newFinalMark);
    }
}